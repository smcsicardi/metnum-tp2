#ifndef KNN_H
#define KNN_H

int kNN(const vector<Punto>& X2, const Punto& y, int k, int clases);

#endif
