#!/bin/bash
# wrapper para ./test
./test $1 < $2
